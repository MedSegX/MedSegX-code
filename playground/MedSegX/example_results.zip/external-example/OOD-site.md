# external cross_site evaluation

- MRI_Prostate
  - prostate158: DSC (0.9716), HD (3.0730)
- ALL
  - Mean: DSC (0.9716), HD (3.0730)
