# external cross_task evaluation

- CT_ColonCancer
  - MSD_Task10: DSC (0.7889), HD (5.0446)
- ALL
  - Mean: DSC (0.7889), HD (5.0446)
