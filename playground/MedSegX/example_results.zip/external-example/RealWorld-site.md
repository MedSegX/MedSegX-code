# external cross_site evaluation

- CT_Consolidation
  - PneumoniaDataset: DSC (0.7273), HD (5.5946)
- ALL
  - Mean: DSC (0.7273), HD (5.5946)
