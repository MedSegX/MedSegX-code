# external cross_task evaluation

- CT_StomachCancer
  - StomachCancerDataset: DSC (0.6316), HD (13.5516)
- ALL
  - Mean: DSC (0.6316), HD (13.5516)
