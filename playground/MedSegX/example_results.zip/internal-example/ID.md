# internal evaluation

- AbdomenCT1K
  - CT_Liver: DSC (0.9832), HD (1.0000)
- ISIC2018
  - Dermoscopy_Skin: DSC (0.9839), HD (14.0702)
- MSD_Task05
  - MRI_ProstatePeripheralZone
    - ADC: DSC (0.9169), HD (3.2394)
    - T2: DSC (0.9437), HD (2.2678)
  - MRI_ProstateTransitionalZone
    - ADC: DSC (0.8349), HD (8.0000)
    - T2: DSC (0.9047), HD (2.9914)
- ALL
  - Mean: DSC (0.9395), HD (5.2146)
